﻿using Car_Management.Models;
using MySql.Data.MySqlClient;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Car_Management.Controllers
{
    public class MobilRepository
    {
        private readonly string _connectionString = "server=localhost;database=db_showroom;uid=root;password=;";

        public List<Mobil> GetAllMobil()
        {
            List<Mobil> daftarMobil = new List<Mobil>();
            using (MySqlConnection conn = new MySqlConnection(_connectionString))
            {
                conn.Open();
                string query = "SELECT id, merek, model, tahun, harga, status, path_gambar, deskripsi FROM mobil";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        daftarMobil.Add(new Mobil
                        {
                            Id = reader.GetInt32("id"),
                            Merek = reader.GetString("merek"),
                            Model = reader.GetString("model"),
                            Tahun = reader.GetInt32("tahun"),
                            Harga = reader.GetDecimal("harga"),
                            Status = reader.GetString("status"),
                            PathGambar = reader.IsDBNull(reader.GetOrdinal("path_gambar")) ? "" : reader.GetString("path_gambar"),
                            Deskripsi = reader.IsDBNull(reader.GetOrdinal("deskripsi")) ? "" : reader.GetString("deskripsi")
                        });
                    }
                }
            }
            return daftarMobil;
        }

        public void AddMobil(Mobil mobil)
        {
            using (MySqlConnection conn = new MySqlConnection(_connectionString))
            {
                try
                {
                    conn.Open();
                    string query = @"INSERT INTO mobil (merek, model, tahun, harga, status, path_gambar, deskripsi) 
                                     VALUES (@merek, @model, @tahun, @harga, @status, @path_gambar, @deskripsi)";
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@merek", mobil.Merek);
                    cmd.Parameters.AddWithValue("@model", mobil.Model);
                    cmd.Parameters.AddWithValue("@tahun", mobil.Tahun);
                    cmd.Parameters.AddWithValue("@harga", mobil.Harga);
                    cmd.Parameters.AddWithValue("@status", mobil.Status);
                    cmd.Parameters.AddWithValue("@path_gambar", mobil.PathGambar);
                    cmd.Parameters.AddWithValue("@deskripsi", mobil.Deskripsi);
                    cmd.ExecuteNonQuery();
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show("Gagal menyimpan data ke database: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        public void UpdateMobil(Mobil mobil)
        {
            using (MySqlConnection conn = new MySqlConnection(_connectionString))
            {
                try
                {
                    conn.Open();
                    string query = @"UPDATE mobil SET 
                                merek = @merek, 
                                model = @model, 
                                tahun = @tahun, 
                                harga = @harga, 
                                status = @status, 
                                path_gambar = @path_gambar, 
                                deskripsi = @deskripsi 
                             WHERE id = @id";

                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@merek", mobil.Merek);
                    cmd.Parameters.AddWithValue("@model", mobil.Model);
                    cmd.Parameters.AddWithValue("@tahun", mobil.Tahun);
                    cmd.Parameters.AddWithValue("@harga", mobil.Harga);
                    cmd.Parameters.AddWithValue("@status", mobil.Status);
                    cmd.Parameters.AddWithValue("@path_gambar", mobil.PathGambar);
                    cmd.Parameters.AddWithValue("@deskripsi", mobil.Deskripsi);
                    cmd.Parameters.AddWithValue("@id", mobil.Id); 

                    cmd.ExecuteNonQuery();
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show("Gagal memperbarui data di database: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        public void DeleteMobil(int id)
        {
            using (MySqlConnection conn = new MySqlConnection(_connectionString))
            {
                try
                {
                    conn.Open();
                    string query = "DELETE FROM mobil WHERE id = @id";
                    MySqlCommand cmd = new MySqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.ExecuteNonQuery();
                }
                catch (MySqlException ex)
                {
                    MessageBox.Show("Gagal menghapus data dari database: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        public List<Mobil> SearchMobil(string keyword)
        {
            List<Mobil> daftarMobil = new List<Mobil>();
            using (MySqlConnection conn = new MySqlConnection(_connectionString))
            {
                conn.Open();
                string query = @"SELECT id, merek, model, tahun, harga, status, path_gambar, deskripsi FROM mobil 
                                 WHERE merek LIKE @keyword OR model LIKE @keyword OR tahun LIKE @keyword";
                MySqlCommand cmd = new MySqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@keyword", "%" + keyword + "%");
                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        daftarMobil.Add(new Mobil
                        {
                            Id = reader.GetInt32("id"),
                            Merek = reader.GetString("merek"),
                            Model = reader.GetString("model"),
                            Tahun = reader.GetInt32("tahun"),
                            Harga = reader.GetDecimal("harga"),
                            Status = reader.GetString("status"),
                            PathGambar = reader.IsDBNull(reader.GetOrdinal("path_gambar")) ? "" : reader.GetString("path_gambar"),
                            Deskripsi = reader.IsDBNull(reader.GetOrdinal("deskripsi")) ? "" : reader.GetString("deskripsi")
                        });
                    }
                }
            }
            return daftarMobil;
        }
    }
}
