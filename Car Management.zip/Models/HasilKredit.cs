﻿using System.Collections.Generic; 

namespace Car_Management.Models
{
    public class HasilKredit
    {
        public decimal TotalPinjaman { get; set; }
        public decimal CicilanBulanan { get; set; }
        public decimal TotalBunga { get; set; }
        public List<AmortisasiDetail> JadwalAmortisasi { get; set; }
    }
}
