﻿using Car_Management.Models;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Car_Management.Controllers
{
    public class KreditController
    {
        public HasilKredit HitungKredit(decimal hargaOtr, decimal dp, double bungaTahunan, int lamaTahun)
        {
            if (dp >= hargaOtr)
            {
                MessageBox.Show("Uang Muka (DP) tidak boleh lebih besar atau sama dengan Harga Mobil.", "Input Tidak Valid", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return null;
            }
            if (lamaTahun <= 0)
            {
                MessageBox.Show("Lama kredit harus dipilih.", "Input Tidak Valid", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return null;
            }
            decimal pokokPinjaman = hargaOtr - dp;
            double bungaBulanan = bungaTahunan / 100 / 12;
            int jumlahBulan = lamaTahun * 12;
            if (bungaBulanan == 0)
            {
                return new HasilKredit
                {
                    TotalPinjaman = pokokPinjaman,
                    CicilanBulanan = pokokPinjaman / jumlahBulan,
                    TotalBunga = 0
                };
            }
            double faktorAnuitas = bungaBulanan * Math.Pow(1 + bungaBulanan, jumlahBulan);
            double pembagiAnuitas = Math.Pow(1 + bungaBulanan, jumlahBulan) - 1;
            decimal cicilanBulanan = pokokPinjaman * (decimal)(faktorAnuitas / pembagiAnuitas);

            List<AmortisasiDetail> jadwal = new List<AmortisasiDetail>();
            decimal sisaPinjaman = pokokPinjaman;

            for (int i = 1; i <= jumlahBulan; i++)
            {
                decimal bungaUntukBulanIni = sisaPinjaman * (decimal)bungaBulanan;
                decimal pokokUntukBulanIni = cicilanBulanan - bungaUntukBulanIni;
                sisaPinjaman -= pokokUntukBulanIni;

                if (i == jumlahBulan)
                {
                    pokokUntukBulanIni += sisaPinjaman;
                    sisaPinjaman = 0;
                }

                jadwal.Add(new AmortisasiDetail
                {
                    BulanKe = i,
                    AngsuranBunga = bungaUntukBulanIni,
                    AngsuranPokok = pokokUntukBulanIni,
                    TotalAngsuran = cicilanBulanan,
                    SisaPinjaman = sisaPinjaman
                });
            }

            decimal totalPembayaran = cicilanBulanan * jumlahBulan;
            decimal totalBunga = totalPembayaran - pokokPinjaman;

            return new HasilKredit
            {
                TotalPinjaman = pokokPinjaman,
                CicilanBulanan = cicilanBulanan,
                TotalBunga = totalBunga,
                JadwalAmortisasi = jadwal
            };
        }
    }
}