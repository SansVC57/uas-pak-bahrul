﻿namespace Car_Management.Models
{
    public class AmortisasiDetail
    {
        public int BulanKe { get; set; }
        public decimal AngsuranPokok { get; set; }
        public decimal AngsuranBunga { get; set; }
        public decimal TotalAngsuran { get; set; }
        public decimal SisaPinjaman { get; set; }
    }
}
