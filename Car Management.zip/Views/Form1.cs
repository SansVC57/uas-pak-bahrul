namespace Car_Management.Views
{
    using Car_Management.Controllers;
    using Car_Management.Models;
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Windows.Forms;
    using static System.Windows.Forms.VisualStyles.VisualStyleElement;

    public partial class Form1 : Form
    {
        private MobilController _mobilController;
        private KreditController _kreditController;
        private UserController _userController;
        private string _selectedImagePath = string.Empty;
        private bool _isInEditMode = false;
        private int _editingMobilId = 0;
        private bool _isLoggedIn = false;
        private User _currentUser = null;

        public Form1()
        {
            InitializeComponent();
            _mobilController = new MobilController(this);
            _kreditController = new KreditController();
            _userController = new UserController();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            _mobilController.LoadAllMobil();
            InisialisasiFormKredit();
            panel4.BringToFront();
        }

        private void InisialisasiFormKredit()
        {
            comboBox1.Items.Add("1 Tahun");
            comboBox1.Items.Add("2 Tahun");
            comboBox1.Items.Add("3 Tahun");
            comboBox1.Items.Add("4 Tahun");
            comboBox1.Items.Add("5 Tahun");
            comboBox1.SelectedIndex = 0;
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow?.DataBoundItem is Mobil mobilTerpilih)
            {
                label1.Text = $"{mobilTerpilih.Merek} {mobilTerpilih.Model} ({mobilTerpilih.Tahun})";
                label3.Text = mobilTerpilih.Harga.ToString("C0", new CultureInfo("id-ID"));
                label5.Text = mobilTerpilih.Deskripsi;
                TampilkanGambarDetail(mobilTerpilih.PathGambar);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!_isLoggedIn)
            {
                MessageBox.Show("Anda harus login untuk mengakses panel ini.", "Akses Ditolak", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            panel1.BringToFront();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (!_isLoggedIn)
            {
                MessageBox.Show("Anda harus login untuk mengakses panel ini.", "Akses Ditolak", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            panel2.BringToFront();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (!_isLoggedIn)
            {
                MessageBox.Show("Anda harus login untuk mengakses panel ini.", "Akses Ditolak", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            panel3.BringToFront();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            panel4.BringToFront();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (_isLoggedIn)
            {
                string namaUser = _currentUser.NamaLengkap;
                _isLoggedIn = false;
                _currentUser = null;
                MessageBox.Show($"Anda telah logout, {namaUser}.", "Logout Berhasil", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            panel4.BringToFront();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            _mobilController.SearchMobil(textBox1.Text);
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Mobil mobilBaru = new Mobil
            {
                Merek = textBox2.Text,
                Model = textBox3.Text,
                Tahun = (int)numericUpDown1.Value,
                Harga = numericUpDown2.Value,
                Status = textBox9.Text,
                Deskripsi = textBox4.Text,
                PathGambar = CopyImageAndGetRelativePath(_selectedImagePath)
            };
            _mobilController.TambahMobil(mobilBaru);
            MessageBox.Show("Data mobil baru berhasil ditambahkan!", "Sukses", MessageBoxButtons.OK, MessageBoxIcon.Information);
            BersihkanFormInput();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (dataGridView2.CurrentRow?.DataBoundItem is Mobil mobilTerpilih)
            {
                _isInEditMode = true;
                _editingMobilId = mobilTerpilih.Id;
                textBox2.Text = mobilTerpilih.Merek;
                textBox3.Text = mobilTerpilih.Model;
                numericUpDown1.Value = mobilTerpilih.Tahun;
                numericUpDown2.Value = mobilTerpilih.Harga;
                textBox9.Text = mobilTerpilih.Status;
                textBox4.Text = mobilTerpilih.Deskripsi;
                _selectedImagePath = mobilTerpilih.PathGambar;
                TampilkanGambarInput(Path.Combine(Application.StartupPath, _selectedImagePath));
            }
            else
            {
                MessageBox.Show("Silakan pilih baris data yang ingin diedit terlebih dahulu.", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (!_isInEditMode)
            {
                MessageBox.Show("Silakan klik tombol 'Edit' pada data yang dipilih sebelum mengonfirmasi.", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            string newImagePath = string.IsNullOrEmpty(_selectedImagePath) || !_selectedImagePath.Contains(Application.StartupPath)
                                  ? CopyImageAndGetRelativePath(_selectedImagePath)
                                  : _selectedImagePath.Replace(Application.StartupPath + Path.DirectorySeparatorChar, "");
            Mobil mobilToUpdate = new Mobil
            {
                Id = _editingMobilId,
                Merek = textBox2.Text,
                Model = textBox3.Text,
                Tahun = (int)numericUpDown1.Value,
                Harga = numericUpDown2.Value,
                Status = textBox9.Text,
                Deskripsi = textBox4.Text,
                PathGambar = newImagePath
            };
            _mobilController.UpdateMobil(mobilToUpdate);
            MessageBox.Show("Data mobil berhasil diperbarui!", "Sukses", MessageBoxButtons.OK, MessageBoxIcon.Information);
            BersihkanFormInput();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            BersihkanFormInput();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            if (dataGridView2.CurrentRow?.DataBoundItem is Mobil mobilTerpilih)
            {
                DialogResult konfirmasi = MessageBox.Show(
                    $"Apakah Anda yakin ingin menghapus mobil: {mobilTerpilih.Merek} {mobilTerpilih.Model}?",
                    "Konfirmasi Penghapusan",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question
                );
                if (konfirmasi == DialogResult.Yes)
                {
                    _mobilController.HapusMobil(mobilTerpilih.Id);
                    MessageBox.Show("Data mobil berhasil dihapus.", "Sukses", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Silakan pilih baris data yang ingin dihapus terlebih dahulu.", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            decimal hargaOtr = numericUpDown3.Value;
            decimal dp = numericUpDown4.Value;
            double bunga = (double)numericUpDown5.Value;
            int lamaTahun = comboBox1.SelectedIndex + 1;
            HasilKredit hasil = _kreditController.HitungKredit(hargaOtr, dp, bunga, lamaTahun);
            if (hasil != null)
            {
                CultureInfo idID = new CultureInfo("id-ID");
                label17.Text = hasil.TotalPinjaman.ToString("C0", idID);
                label15.Text = hasil.CicilanBulanan.ToString("C0", idID);
                label16.Text = hasil.TotalBunga.ToString("C0", idID);
                TampilkanJadwalAmortisasi(hasil.JadwalAmortisasi);
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            string nama = textBox7.Text;
            string email = textBox5.Text;
            string password = textBox6.Text;
            if (string.IsNullOrWhiteSpace(nama) || string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Semua field registrasi harus diisi.", "Peringatan", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            _userController.Register(nama, email, password);
        }

        private void button16_Click(object sender, EventArgs e)
        {
            string email = textBox8.Text;
            string password = textBox10.Text;
            User user = _userController.Login(email, password);
            if (user != null)
            {
                _isLoggedIn = true;
                _currentUser = user;
                MessageBox.Show($"Selamat datang, {user.NamaLengkap}!", "Login Berhasil", MessageBoxButtons.OK, MessageBoxIcon.Information);
                panel1.BringToFront();
            }
            else
            {
                MessageBox.Show("Email atau Password salah.", "Login Gagal", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button15_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "Image Files|*.jpg;*.jpeg;*.png;*.gif;*.bmp",
                Title = "Pilih Gambar Mobil"
            };
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                _selectedImagePath = openFileDialog.FileName;
                TampilkanGambarInput(_selectedImagePath);
            }
        }

        public void TampilkanDataDiGrid(List<Mobil> daftarMobil)
        {
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = daftarMobil;
            dataGridView2.DataSource = null;
            dataGridView2.DataSource = daftarMobil;
        }

        private void TampilkanJadwalAmortisasi(List<AmortisasiDetail> jadwal)
        {
            dataGridView3.DataSource = null;
            dataGridView3.DataSource = jadwal;
            if (dataGridView3.Columns.Count > 0)
            {
                CultureInfo idID = new CultureInfo("id-ID");
                dataGridView3.Columns["AngsuranPokok"].DefaultCellStyle.Format = "C0";
                dataGridView3.Columns["AngsuranPokok"].DefaultCellStyle.FormatProvider = idID;
                dataGridView3.Columns["AngsuranBunga"].DefaultCellStyle.Format = "C0";
                dataGridView3.Columns["AngsuranBunga"].DefaultCellStyle.FormatProvider = idID;
                dataGridView3.Columns["TotalAngsuran"].DefaultCellStyle.Format = "C0";
                dataGridView3.Columns["TotalAngsuran"].DefaultCellStyle.FormatProvider = idID;
                dataGridView3.Columns["SisaPinjaman"].DefaultCellStyle.Format = "C0";
                dataGridView3.Columns["SisaPinjaman"].DefaultCellStyle.FormatProvider = idID;
                dataGridView3.Columns["BulanKe"].HeaderText = "Bulan Ke";
                dataGridView3.Columns["AngsuranPokok"].HeaderText = "Angsuran Pokok";
                dataGridView3.Columns["AngsuranBunga"].HeaderText = "Angsuran Bunga";
                dataGridView3.Columns["TotalAngsuran"].HeaderText = "Total Angsuran";
                dataGridView3.Columns["SisaPinjaman"].HeaderText = "Sisa Pinjaman";
                dataGridView3.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            }
        }

        private void BersihkanFormInput()
        {
            textBox2.Clear();
            textBox3.Clear();
            numericUpDown1.Value = DateTime.Now.Year;
            numericUpDown2.Value = 0;
            textBox9.Clear();
            textBox4.Clear();
            pictureBox2.Image = null;
            _selectedImagePath = string.Empty;
            _isInEditMode = false;
            _editingMobilId = 0;
        }

        private void TampilkanGambarDetail(string pathGambarRelatif)
        {
            pictureBox1.Image = null;
            if (!string.IsNullOrEmpty(pathGambarRelatif))
            {
                string pathGambarLengkap = Path.Combine(Application.StartupPath, pathGambarRelatif);
                if (File.Exists(pathGambarLengkap))
                {
                    pictureBox1.Image = new System.Drawing.Bitmap(pathGambarLengkap);
                    pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
                }
            }
        }

        private void TampilkanGambarInput(string pathGambarLengkap)
        {
            pictureBox2.Image = null;
            if (File.Exists(pathGambarLengkap))
            {
                pictureBox2.Image = new System.Drawing.Bitmap(pathGambarLengkap);
                pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            }
        }

        private string CopyImageAndGetRelativePath(string sourcePath)
        {
            if (string.IsNullOrEmpty(sourcePath) || sourcePath.Contains(Application.StartupPath))
            {
                return sourcePath.Replace(Application.StartupPath + Path.DirectorySeparatorChar, "");
            }
            string destinationFolder = Path.Combine(Application.StartupPath, "Images");
            if (!Directory.Exists(destinationFolder))
            {
                Directory.CreateDirectory(destinationFolder);
            }
            string fileName = Guid.NewGuid().ToString() + Path.GetExtension(sourcePath);
            string destinationPath = Path.Combine(destinationFolder, fileName);
            try
            {
                File.Copy(sourcePath, destinationPath);
                return Path.Combine("Images", fileName);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Gagal menyimpan gambar: " + ex.Message);
                return string.Empty;
            }
        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e) { }
        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e) { }
        private void groupBox1_Enter(object sender, EventArgs e) { }
        private void label7_Click(object sender, EventArgs e) { }
        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e) { }
        private void label11_Click(object sender, EventArgs e) { }
        private void groupBox3_Enter(object sender, EventArgs e) { }
        private void textBox9_TextChanged(object sender, EventArgs e) { }
        private void numericUpDown3_ValueChanged(object sender, EventArgs e) { }
        private void numericUpDown4_ValueChanged(object sender, EventArgs e) { }
        private void numericUpDown5_ValueChanged(object sender, EventArgs e) { }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e) { }
        private void label17_Click(object sender, EventArgs e) { }
        private void label15_Click(object sender, EventArgs e) { }
        private void label16_Click(object sender, EventArgs e) { }
        private void dataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e) { }
        private void label19_Click(object sender, EventArgs e) { }
        private void textBox8_TextChanged(object sender, EventArgs e) { }
        private void textBox7_TextChanged(object sender, EventArgs e) { }
        private void textBox5_TextChanged(object sender, EventArgs e) { }
        private void textBox6_TextChanged(object sender, EventArgs e) { }
        private void label6_Click(object sender, EventArgs e) { }
        private void label18_Click(object sender, EventArgs e) { }
        private void textBox11_TextChanged(object sender, EventArgs e) { }
        private void textBox10_TextChanged(object sender, EventArgs e) { }
        private void panel1_Paint(object sender, PaintEventArgs e) { }
        private void label19_Click_1(object sender, EventArgs e) { }
        private void label16_Click_1(object sender, EventArgs e) { }

    }
}
