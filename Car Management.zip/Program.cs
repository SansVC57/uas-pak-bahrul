using Car_Management.Views;

namespace Car_Management
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();

            // Kode ini sekarang akan berjalan tanpa error
            Application.Run(new Form1());
        }
    }
}
