﻿namespace Car_Management.Views
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            button5 = new Button();
            button4 = new Button();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            panel4 = new Panel();
            label28 = new Label();
            label27 = new Label();
            textBox8 = new TextBox();
            label18 = new Label();
            button16 = new Button();
            textBox10 = new TextBox();
            groupBox3 = new GroupBox();
            label26 = new Label();
            label25 = new Label();
            label19 = new Label();
            textBox7 = new TextBox();
            label24 = new Label();
            button13 = new Button();
            textBox6 = new TextBox();
            textBox5 = new TextBox();
            panel3 = new Panel();
            label23 = new Label();
            dataGridView3 = new DataGridView();
            groupBox2 = new GroupBox();
            label22 = new Label();
            label21 = new Label();
            label16 = new Label();
            label4 = new Label();
            label17 = new Label();
            label15 = new Label();
            button12 = new Button();
            comboBox1 = new ComboBox();
            label14 = new Label();
            numericUpDown5 = new NumericUpDown();
            label13 = new Label();
            numericUpDown4 = new NumericUpDown();
            label12 = new Label();
            numericUpDown3 = new NumericUpDown();
            label11 = new Label();
            panel2 = new Panel();
            dataGridView2 = new DataGridView();
            button11 = new Button();
            button10 = new Button();
            button9 = new Button();
            groupBox1 = new GroupBox();
            pictureBox2 = new PictureBox();
            textBox4 = new TextBox();
            label2 = new Label();
            button15 = new Button();
            textBox9 = new TextBox();
            label20 = new Label();
            button7 = new Button();
            numericUpDown2 = new NumericUpDown();
            numericUpDown1 = new NumericUpDown();
            textBox3 = new TextBox();
            textBox2 = new TextBox();
            label10 = new Label();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            button8 = new Button();
            splitContainer1 = new SplitContainer();
            dataGridView1 = new DataGridView();
            button6 = new Button();
            textBox1 = new TextBox();
            label5 = new Label();
            label3 = new Label();
            label1 = new Label();
            pictureBox1 = new PictureBox();
            panel1 = new Panel();
            label6 = new Label();
            panel4.SuspendLayout();
            groupBox3.SuspendLayout();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView3).BeginInit();
            groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDown5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown3).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).BeginInit();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)splitContainer1).BeginInit();
            splitContainer1.Panel1.SuspendLayout();
            splitContainer1.Panel2.SuspendLayout();
            splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // button5
            // 
            button5.BackColor = SystemColors.ControlLightLight;
            button5.FlatStyle = FlatStyle.Flat;
            button5.Location = new Point(0, 413);
            button5.Name = "button5";
            button5.Size = new Size(100, 23);
            button5.TabIndex = 8;
            button5.Text = "Logout";
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click;
            // 
            // button4
            // 
            button4.BackColor = SystemColors.ControlLightLight;
            button4.FlatStyle = FlatStyle.Flat;
            button4.Location = new Point(0, 378);
            button4.Name = "button4";
            button4.Size = new Size(100, 23);
            button4.TabIndex = 7;
            button4.Text = "Login";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // button3
            // 
            button3.BackColor = SystemColors.ControlLightLight;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Location = new Point(0, 141);
            button3.Name = "button3";
            button3.Size = new Size(100, 23);
            button3.TabIndex = 6;
            button3.Text = "Kredit";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.BackColor = SystemColors.ControlLightLight;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Location = new Point(0, 112);
            button2.Name = "button2";
            button2.Size = new Size(100, 23);
            button2.TabIndex = 5;
            button2.Text = "Input";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.BackColor = SystemColors.ControlLightLight;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Location = new Point(0, 83);
            button1.Name = "button1";
            button1.Size = new Size(100, 23);
            button1.TabIndex = 4;
            button1.Text = "Data";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // panel4
            // 
            panel4.BackColor = SystemColors.ControlLightLight;
            panel4.BackgroundImage = (Image)resources.GetObject("panel4.BackgroundImage");
            panel4.BackgroundImageLayout = ImageLayout.Stretch;
            panel4.BorderStyle = BorderStyle.FixedSingle;
            panel4.Controls.Add(label28);
            panel4.Controls.Add(label27);
            panel4.Controls.Add(textBox8);
            panel4.Controls.Add(label18);
            panel4.Controls.Add(button16);
            panel4.Controls.Add(textBox10);
            panel4.Controls.Add(groupBox3);
            panel4.Location = new Point(101, -2);
            panel4.Name = "panel4";
            panel4.Size = new Size(822, 453);
            panel4.TabIndex = 3;
            // 
            // label28
            // 
            label28.AutoSize = true;
            label28.BackColor = Color.Transparent;
            label28.Location = new Point(113, 232);
            label28.Name = "label28";
            label28.Size = new Size(57, 15);
            label28.TabIndex = 12;
            label28.Text = "Password";
            // 
            // label27
            // 
            label27.AutoSize = true;
            label27.BackColor = Color.Transparent;
            label27.Location = new Point(113, 192);
            label27.Name = "label27";
            label27.Size = new Size(36, 15);
            label27.TabIndex = 11;
            label27.Text = "Email";
            // 
            // textBox8
            // 
            textBox8.Location = new Point(176, 189);
            textBox8.Name = "textBox8";
            textBox8.Size = new Size(124, 23);
            textBox8.TabIndex = 10;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.BackColor = Color.Transparent;
            label18.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold);
            label18.Location = new Point(176, 72);
            label18.Name = "label18";
            label18.Size = new Size(99, 37);
            label18.TabIndex = 9;
            label18.Text = "LOGIN";
            label18.Click += label18_Click;
            // 
            // button16
            // 
            button16.FlatStyle = FlatStyle.Flat;
            button16.Location = new Point(178, 266);
            button16.Name = "button16";
            button16.Size = new Size(122, 23);
            button16.TabIndex = 8;
            button16.Text = "Login";
            button16.UseVisualStyleBackColor = true;
            button16.Click += button16_Click;
            // 
            // textBox10
            // 
            textBox10.Location = new Point(176, 229);
            textBox10.Name = "textBox10";
            textBox10.Size = new Size(124, 23);
            textBox10.TabIndex = 7;
            textBox10.TextChanged += textBox10_TextChanged;
            // 
            // groupBox3
            // 
            groupBox3.BackgroundImage = (Image)resources.GetObject("groupBox3.BackgroundImage");
            groupBox3.BackgroundImageLayout = ImageLayout.Stretch;
            groupBox3.Controls.Add(label26);
            groupBox3.Controls.Add(label25);
            groupBox3.Controls.Add(label19);
            groupBox3.Controls.Add(textBox7);
            groupBox3.Controls.Add(label24);
            groupBox3.Controls.Add(button13);
            groupBox3.Controls.Add(textBox6);
            groupBox3.Controls.Add(textBox5);
            groupBox3.Location = new Point(411, -13);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(411, 485);
            groupBox3.TabIndex = 0;
            groupBox3.TabStop = false;
            groupBox3.Enter += groupBox3_Enter;
            // 
            // label26
            // 
            label26.AutoSize = true;
            label26.BackColor = Color.Transparent;
            label26.ForeColor = SystemColors.ActiveCaptionText;
            label26.Location = new Point(113, 254);
            label26.Name = "label26";
            label26.Size = new Size(57, 15);
            label26.TabIndex = 9;
            label26.Text = "Password";
            // 
            // label25
            // 
            label25.AutoSize = true;
            label25.BackColor = Color.Transparent;
            label25.ForeColor = SystemColors.ActiveCaptionText;
            label25.Location = new Point(114, 214);
            label25.Name = "label25";
            label25.Size = new Size(36, 15);
            label25.TabIndex = 8;
            label25.Text = "Email";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.BackColor = Color.Transparent;
            label19.ForeColor = SystemColors.ActiveCaptionText;
            label19.Location = new Point(115, 175);
            label19.Name = "label19";
            label19.Size = new Size(39, 15);
            label19.TabIndex = 7;
            label19.Text = "Nama";
            label19.Click += label19_Click_1;
            // 
            // textBox7
            // 
            textBox7.Location = new Point(174, 172);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(124, 23);
            textBox7.TabIndex = 6;
            // 
            // label24
            // 
            label24.AutoSize = true;
            label24.BackColor = Color.Transparent;
            label24.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold);
            label24.ForeColor = SystemColors.ActiveCaptionText;
            label24.Location = new Point(158, 95);
            label24.Name = "label24";
            label24.Size = new Size(140, 37);
            label24.TabIndex = 5;
            label24.Text = "REGISTER";
            // 
            // button13
            // 
            button13.FlatStyle = FlatStyle.Flat;
            button13.Location = new Point(174, 288);
            button13.Name = "button13";
            button13.Size = new Size(124, 23);
            button13.TabIndex = 3;
            button13.Text = "Register";
            button13.UseVisualStyleBackColor = true;
            button13.Click += button13_Click;
            // 
            // textBox6
            // 
            textBox6.Location = new Point(174, 250);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(124, 23);
            textBox6.TabIndex = 2;
            textBox6.TextChanged += textBox6_TextChanged;
            // 
            // textBox5
            // 
            textBox5.Location = new Point(174, 210);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(124, 23);
            textBox5.TabIndex = 1;
            textBox5.TextChanged += textBox5_TextChanged;
            // 
            // panel3
            // 
            panel3.BackColor = SystemColors.ControlLightLight;
            panel3.BackgroundImage = (Image)resources.GetObject("panel3.BackgroundImage");
            panel3.BorderStyle = BorderStyle.FixedSingle;
            panel3.Controls.Add(label23);
            panel3.Controls.Add(dataGridView3);
            panel3.Controls.Add(groupBox2);
            panel3.Location = new Point(101, -1);
            panel3.Name = "panel3";
            panel3.Size = new Size(822, 453);
            panel3.TabIndex = 2;
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.BackColor = Color.Transparent;
            label23.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label23.ForeColor = SystemColors.ActiveCaptionText;
            label23.Location = new Point(19, 17);
            label23.Name = "label23";
            label23.Size = new Size(218, 32);
            label23.TabIndex = 4;
            label23.Text = "SIMULASI KREDIT";
            // 
            // dataGridView3
            // 
            dataGridView3.BackgroundColor = SystemColors.Control;
            dataGridView3.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView3.Location = new Point(19, 251);
            dataGridView3.Name = "dataGridView3";
            dataGridView3.Size = new Size(785, 190);
            dataGridView3.TabIndex = 1;
            dataGridView3.CellContentClick += dataGridView3_CellContentClick;
            // 
            // groupBox2
            // 
            groupBox2.BackColor = SystemColors.Control;
            groupBox2.Controls.Add(label22);
            groupBox2.Controls.Add(label21);
            groupBox2.Controls.Add(label16);
            groupBox2.Controls.Add(label4);
            groupBox2.Controls.Add(label17);
            groupBox2.Controls.Add(label15);
            groupBox2.Controls.Add(button12);
            groupBox2.Controls.Add(comboBox1);
            groupBox2.Controls.Add(label14);
            groupBox2.Controls.Add(numericUpDown5);
            groupBox2.Controls.Add(label13);
            groupBox2.Controls.Add(numericUpDown4);
            groupBox2.Controls.Add(label12);
            groupBox2.Controls.Add(numericUpDown3);
            groupBox2.Controls.Add(label11);
            groupBox2.Location = new Point(19, 71);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(785, 166);
            groupBox2.TabIndex = 0;
            groupBox2.TabStop = false;
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.ForeColor = SystemColors.ActiveCaptionText;
            label22.Location = new Point(404, 77);
            label22.Name = "label22";
            label22.Size = new Size(99, 15);
            label22.TabIndex = 15;
            label22.Text = "Cicilan perbulan :";
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.ForeColor = SystemColors.ActiveCaptionText;
            label21.Location = new Point(404, 22);
            label21.Name = "label21";
            label21.Size = new Size(100, 15);
            label21.TabIndex = 14;
            label21.Text = "Total Pinjaman    :";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.ForeColor = SystemColors.ActiveCaptionText;
            label16.Location = new Point(514, 51);
            label16.Name = "label16";
            label16.Size = new Size(12, 15);
            label16.TabIndex = 13;
            label16.Text = "-";
            label16.Click += label16_Click_1;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.ForeColor = SystemColors.ActiveCaptionText;
            label4.Location = new Point(405, 48);
            label4.Name = "label4";
            label4.Size = new Size(99, 15);
            label4.TabIndex = 12;
            label4.Text = "Total Bunga         :";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.ForeColor = SystemColors.ActiveCaptionText;
            label17.Location = new Point(514, 22);
            label17.Name = "label17";
            label17.Size = new Size(12, 15);
            label17.TabIndex = 11;
            label17.Text = "-";
            label17.Click += label17_Click;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.ForeColor = SystemColors.ActiveCaptionText;
            label15.Location = new Point(514, 77);
            label15.Name = "label15";
            label15.Size = new Size(12, 15);
            label15.TabIndex = 9;
            label15.Text = "-";
            label15.Click += label15_Click;
            // 
            // button12
            // 
            button12.BackColor = SystemColors.ControlLightLight;
            button12.FlatStyle = FlatStyle.Flat;
            button12.ForeColor = SystemColors.ActiveCaptionText;
            button12.Location = new Point(17, 137);
            button12.Name = "button12";
            button12.Size = new Size(75, 23);
            button12.TabIndex = 8;
            button12.Text = "Hitung";
            button12.UseVisualStyleBackColor = false;
            button12.Click += button12_Click;
            // 
            // comboBox1
            // 
            comboBox1.BackColor = SystemColors.ControlLightLight;
            comboBox1.ForeColor = SystemColors.ActiveCaptionText;
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(144, 103);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(121, 23);
            comboBox1.TabIndex = 7;
            comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.ForeColor = SystemColors.ActiveCaptionText;
            label14.Location = new Point(17, 106);
            label14.Name = "label14";
            label14.Size = new Size(69, 15);
            label14.TabIndex = 6;
            label14.Text = "Lama kredit";
            // 
            // numericUpDown5
            // 
            numericUpDown5.BackColor = SystemColors.ControlLightLight;
            numericUpDown5.ForeColor = SystemColors.ActiveCaptionText;
            numericUpDown5.Location = new Point(145, 72);
            numericUpDown5.Maximum = new decimal(new int[] { -727379969, 232, 0, 0 });
            numericUpDown5.Name = "numericUpDown5";
            numericUpDown5.Size = new Size(120, 23);
            numericUpDown5.TabIndex = 5;
            numericUpDown5.ValueChanged += numericUpDown5_ValueChanged;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.ForeColor = SystemColors.ActiveCaptionText;
            label13.Location = new Point(17, 77);
            label13.Name = "label13";
            label13.Size = new Size(95, 15);
            label13.TabIndex = 4;
            label13.Text = "Bunga per tahun";
            // 
            // numericUpDown4
            // 
            numericUpDown4.BackColor = SystemColors.ControlLightLight;
            numericUpDown4.ForeColor = SystemColors.ActiveCaptionText;
            numericUpDown4.Location = new Point(145, 43);
            numericUpDown4.Maximum = new decimal(new int[] { -727379969, 232, 0, 0 });
            numericUpDown4.Name = "numericUpDown4";
            numericUpDown4.Size = new Size(120, 23);
            numericUpDown4.TabIndex = 3;
            numericUpDown4.ValueChanged += numericUpDown4_ValueChanged;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.ForeColor = SystemColors.ActiveCaptionText;
            label12.Location = new Point(17, 48);
            label12.Name = "label12";
            label12.Size = new Size(63, 15);
            label12.TabIndex = 2;
            label12.Text = "Jumlah Dp";
            // 
            // numericUpDown3
            // 
            numericUpDown3.BackColor = SystemColors.ControlLightLight;
            numericUpDown3.ForeColor = SystemColors.ActiveCaptionText;
            numericUpDown3.Location = new Point(145, 14);
            numericUpDown3.Maximum = new decimal(new int[] { -727379969, 232, 0, 0 });
            numericUpDown3.Name = "numericUpDown3";
            numericUpDown3.Size = new Size(120, 23);
            numericUpDown3.TabIndex = 1;
            numericUpDown3.ValueChanged += numericUpDown3_ValueChanged;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.ForeColor = SystemColors.ActiveCaptionText;
            label11.Location = new Point(17, 19);
            label11.Name = "label11";
            label11.Size = new Size(97, 15);
            label11.TabIndex = 0;
            label11.Text = "Harga OTR Mobil";
            label11.Click += label11_Click;
            // 
            // panel2
            // 
            panel2.BackColor = SystemColors.ControlLightLight;
            panel2.BackgroundImage = (Image)resources.GetObject("panel2.BackgroundImage");
            panel2.BorderStyle = BorderStyle.FixedSingle;
            panel2.Controls.Add(dataGridView2);
            panel2.Controls.Add(button11);
            panel2.Controls.Add(button10);
            panel2.Controls.Add(button9);
            panel2.Controls.Add(groupBox1);
            panel2.Controls.Add(button8);
            panel2.Location = new Point(101, -1);
            panel2.Name = "panel2";
            panel2.Size = new Size(822, 453);
            panel2.TabIndex = 1;
            // 
            // dataGridView2
            // 
            dataGridView2.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView2.BackgroundColor = SystemColors.Control;
            dataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView2.Location = new Point(21, 231);
            dataGridView2.Name = "dataGridView2";
            dataGridView2.ReadOnly = true;
            dataGridView2.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView2.Size = new Size(779, 204);
            dataGridView2.TabIndex = 11;
            dataGridView2.CellContentClick += dataGridView2_CellContentClick;
            // 
            // button11
            // 
            button11.BackColor = SystemColors.ControlLightLight;
            button11.FlatStyle = FlatStyle.Flat;
            button11.Location = new Point(402, 190);
            button11.Name = "button11";
            button11.Size = new Size(100, 23);
            button11.TabIndex = 16;
            button11.Text = "Hapus";
            button11.UseVisualStyleBackColor = false;
            button11.Click += button11_Click;
            // 
            // button10
            // 
            button10.BackColor = SystemColors.ControlLightLight;
            button10.FlatStyle = FlatStyle.Flat;
            button10.Location = new Point(273, 190);
            button10.Name = "button10";
            button10.Size = new Size(100, 23);
            button10.TabIndex = 15;
            button10.Text = "clear";
            button10.UseVisualStyleBackColor = false;
            button10.Click += button10_Click;
            // 
            // button9
            // 
            button9.BackColor = SystemColors.ControlLightLight;
            button9.FlatStyle = FlatStyle.Flat;
            button9.Location = new Point(147, 190);
            button9.Name = "button9";
            button9.Size = new Size(100, 23);
            button9.TabIndex = 14;
            button9.Text = "Konfirmasi Edit";
            button9.UseVisualStyleBackColor = false;
            button9.Click += button9_Click;
            // 
            // groupBox1
            // 
            groupBox1.BackColor = SystemColors.Control;
            groupBox1.Controls.Add(pictureBox2);
            groupBox1.Controls.Add(textBox4);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(button15);
            groupBox1.Controls.Add(textBox9);
            groupBox1.Controls.Add(label20);
            groupBox1.Controls.Add(button7);
            groupBox1.Controls.Add(numericUpDown2);
            groupBox1.Controls.Add(numericUpDown1);
            groupBox1.Controls.Add(textBox3);
            groupBox1.Controls.Add(textBox2);
            groupBox1.Controls.Add(label10);
            groupBox1.Controls.Add(label9);
            groupBox1.Controls.Add(label8);
            groupBox1.Controls.Add(label7);
            groupBox1.Location = new Point(22, 15);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(778, 160);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Enter += groupBox1_Enter;
            // 
            // pictureBox2
            // 
            pictureBox2.Location = new Point(518, 40);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(120, 50);
            pictureBox2.TabIndex = 19;
            pictureBox2.TabStop = false;
            // 
            // textBox4
            // 
            textBox4.BackColor = SystemColors.ControlLightLight;
            textBox4.Location = new Point(363, 77);
            textBox4.Multiline = true;
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(120, 55);
            textBox4.TabIndex = 18;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(303, 77);
            label2.Name = "label2";
            label2.Size = new Size(54, 15);
            label2.TabIndex = 17;
            label2.Text = "Deskripsi";
            // 
            // button15
            // 
            button15.BackColor = SystemColors.ControlLightLight;
            button15.FlatStyle = FlatStyle.Flat;
            button15.Location = new Point(518, 109);
            button15.Name = "button15";
            button15.Size = new Size(120, 23);
            button15.TabIndex = 16;
            button15.Text = "Upload Gambar";
            button15.UseVisualStyleBackColor = false;
            button15.Click += button15_Click;
            // 
            // textBox9
            // 
            textBox9.BackColor = SystemColors.ControlLightLight;
            textBox9.Location = new Point(363, 37);
            textBox9.Name = "textBox9";
            textBox9.Size = new Size(120, 23);
            textBox9.TabIndex = 15;
            textBox9.TextChanged += textBox9_TextChanged;
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Location = new Point(304, 43);
            label20.Name = "label20";
            label20.Size = new Size(39, 15);
            label20.TabIndex = 14;
            label20.Text = "Status";
            // 
            // button7
            // 
            button7.BackColor = SystemColors.ControlLightLight;
            button7.FlatStyle = FlatStyle.Flat;
            button7.Location = new Point(656, 39);
            button7.Name = "button7";
            button7.Size = new Size(108, 93);
            button7.TabIndex = 9;
            button7.Text = "Input";
            button7.UseVisualStyleBackColor = false;
            button7.Click += button7_Click;
            // 
            // numericUpDown2
            // 
            numericUpDown2.BackColor = SystemColors.ControlLightLight;
            numericUpDown2.Location = new Point(188, 96);
            numericUpDown2.Maximum = new decimal(new int[] { -727379969, 232, 0, 0 });
            numericUpDown2.Name = "numericUpDown2";
            numericUpDown2.Size = new Size(82, 23);
            numericUpDown2.TabIndex = 11;
            // 
            // numericUpDown1
            // 
            numericUpDown1.BackColor = SystemColors.ControlLightLight;
            numericUpDown1.Location = new Point(188, 40);
            numericUpDown1.Maximum = new decimal(new int[] { 10000, 0, 0, 0 });
            numericUpDown1.Name = "numericUpDown1";
            numericUpDown1.Size = new Size(82, 23);
            numericUpDown1.TabIndex = 10;
            // 
            // textBox3
            // 
            textBox3.BackColor = SystemColors.ControlLightLight;
            textBox3.Location = new Point(50, 96);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(82, 23);
            textBox3.TabIndex = 5;
            // 
            // textBox2
            // 
            textBox2.BackColor = SystemColors.ControlLightLight;
            textBox2.Location = new Point(50, 40);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(82, 23);
            textBox2.TabIndex = 4;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(144, 102);
            label10.Name = "label10";
            label10.Size = new Size(39, 15);
            label10.TabIndex = 3;
            label10.Text = "Harga";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(144, 42);
            label9.Name = "label9";
            label9.Size = new Size(39, 15);
            label9.TabIndex = 2;
            label9.Text = "Tahun";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(6, 99);
            label8.Name = "label8";
            label8.Size = new Size(41, 15);
            label8.TabIndex = 1;
            label8.Text = "Model";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(6, 42);
            label7.Name = "label7";
            label7.Size = new Size(40, 15);
            label7.TabIndex = 0;
            label7.Text = "Merek";
            // 
            // button8
            // 
            button8.BackColor = SystemColors.ControlLightLight;
            button8.FlatStyle = FlatStyle.Flat;
            button8.Location = new Point(22, 190);
            button8.Name = "button8";
            button8.Size = new Size(100, 23);
            button8.TabIndex = 13;
            button8.Text = "Edit";
            button8.UseVisualStyleBackColor = false;
            button8.Click += button8_Click;
            // 
            // splitContainer1
            // 
            splitContainer1.BackColor = SystemColors.Control;
            splitContainer1.Location = new Point(0, 71);
            splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            splitContainer1.Panel1.BackColor = SystemColors.Control;
            splitContainer1.Panel1.Controls.Add(dataGridView1);
            splitContainer1.Panel1.Controls.Add(button6);
            splitContainer1.Panel1.Controls.Add(textBox1);
            // 
            // splitContainer1.Panel2
            // 
            splitContainer1.Panel2.BackColor = SystemColors.Control;
            splitContainer1.Panel2.Controls.Add(label5);
            splitContainer1.Panel2.Controls.Add(label3);
            splitContainer1.Panel2.Controls.Add(label1);
            splitContainer1.Panel2.Controls.Add(pictureBox1);
            splitContainer1.Size = new Size(822, 382);
            splitContainer1.SplitterDistance = 482;
            splitContainer1.TabIndex = 2;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(21, 41);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.Size = new Size(458, 322);
            dataGridView1.TabIndex = 10;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick_1;
            dataGridView1.SelectionChanged += dataGridView1_SelectionChanged;
            // 
            // button6
            // 
            button6.BackColor = SystemColors.ControlLightLight;
            button6.FlatStyle = FlatStyle.Flat;
            button6.Location = new Point(420, 12);
            button6.Name = "button6";
            button6.Size = new Size(59, 23);
            button6.TabIndex = 9;
            button6.Text = "Cari";
            button6.UseVisualStyleBackColor = false;
            button6.Click += button6_Click;
            // 
            // textBox1
            // 
            textBox1.BackColor = SystemColors.ControlLightLight;
            textBox1.Location = new Point(21, 12);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(393, 23);
            textBox1.TabIndex = 0;
            // 
            // label5
            // 
            label5.BackColor = SystemColors.ControlLightLight;
            label5.BorderStyle = BorderStyle.FixedSingle;
            label5.Location = new Point(24, 281);
            label5.Name = "label5";
            label5.Size = new Size(290, 82);
            label5.TabIndex = 5;
            label5.Text = "label5";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(22, 241);
            label3.Name = "label3";
            label3.Size = new Size(50, 20);
            label3.TabIndex = 3;
            label3.Text = "label3";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(20, 210);
            label1.Name = "label1";
            label1.Size = new Size(76, 25);
            label1.TabIndex = 1;
            label1.Text = "label1";
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = SystemColors.ControlLightLight;
            pictureBox1.BorderStyle = BorderStyle.FixedSingle;
            pictureBox1.Location = new Point(24, 11);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(290, 189);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            panel1.BackgroundImage = (Image)resources.GetObject("panel1.BackgroundImage");
            panel1.BorderStyle = BorderStyle.FixedSingle;
            panel1.Controls.Add(label6);
            panel1.Controls.Add(splitContainer1);
            panel1.Location = new Point(101, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(822, 453);
            panel1.TabIndex = 0;
            panel1.Paint += panel1_Paint;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.ForeColor = SystemColors.ActiveCaptionText;
            label6.Location = new Point(22, 17);
            label6.Name = "label6";
            label6.Size = new Size(325, 32);
            label6.TabIndex = 3;
            label6.Text = "MANAJEMEN SHOWROOM";
            label6.Click += label6_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Control;
            BackgroundImageLayout = ImageLayout.None;
            ClientSize = new Size(921, 446);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(panel4);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView3).EndInit();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)numericUpDown5).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown4).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown3).EndInit();
            panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView2).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown2).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDown1).EndInit();
            splitContainer1.Panel1.ResumeLayout(false);
            splitContainer1.Panel1.PerformLayout();
            splitContainer1.Panel2.ResumeLayout(false);
            splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)splitContainer1).EndInit();
            splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Button button5;
        private Button button4;
        private Button button3;
        private Button button2;
        private Button button1;
        private Panel panel4;
        private Panel panel3;
        private Panel panel2;
        private SplitContainer splitContainer1;
        private DataGridView dataGridView1;
        private Button button6;
        private TextBox textBox1;
        private PictureBox pictureBox1;
        private Panel panel1;
        private Label label1;
        private Label label5;
        private Label label3;
        private Label label6;
        private GroupBox groupBox1;
        private Button button8;
        private Button button7;
        private NumericUpDown numericUpDown2;
        private NumericUpDown numericUpDown1;
        private TextBox textBox3;
        private TextBox textBox2;
        private Label label10;
        private Label label9;
        private Label label8;
        private Label label7;
        private DataGridView dataGridView2;
        private Button button11;
        private Button button10;
        private Button button9;
        private GroupBox groupBox2;
        private NumericUpDown numericUpDown3;
        private Label label11;
        private GroupBox groupBox3;
        private Button button13;
        private TextBox textBox6;
        private TextBox textBox5;
        private DataGridView dataGridView3;
        private Label label17;
        private Label label15;
        private Button button12;
        private ComboBox comboBox1;
        private Label label14;
        private NumericUpDown numericUpDown5;
        private Label label13;
        private NumericUpDown numericUpDown4;
        private Label label12;
        private TextBox textBox9;
        private Label label20;
        private Button button15;
        private TextBox textBox4;
        private Label label2;
        private PictureBox pictureBox2;
        private Label label4;
        private Label label22;
        private Label label21;
        private Label label16;
        private Label label23;
        private Label label24;
        private Label label18;
        private Button button16;
        private TextBox textBox10;
        private Label label19;
        private TextBox textBox7;
        private Label label26;
        private Label label25;
        private Label label28;
        private Label label27;
        private TextBox textBox8;
    }
}
