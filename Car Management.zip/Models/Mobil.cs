﻿namespace Car_Management.Models
{
    public class Mobil
    {
        public int Id { get; set; }
        public string Merek { get; set; } = string.Empty;
        public string Model { get; set; } = string.Empty;
        public int Tahun { get; set; }
        public decimal Harga { get; set; }
        public string Status { get; set; } = string.Empty;
        public string PathGambar { get; set; } = string.Empty;
        public string Deskripsi { get; set; } = string.Empty;
    }
}
