﻿using Car_Management.Models;
using Car_Management.Views;
namespace Car_Management.Controllers
{
    public class MobilController
    {
        private readonly Form1 _view;
        private readonly MobilRepository _mobilRepository; 
        public MobilController(Form1 view)
        {
            _view = view;
            _mobilRepository = new MobilRepository(); 
        }

        public void LoadAllMobil()
        {
            var daftarMobil = _mobilRepository.GetAllMobil();
            _view.TampilkanDataDiGrid(daftarMobil);
        }

        public void SearchMobil(string keyword)
        {
            if (string.IsNullOrWhiteSpace(keyword))
            {
                LoadAllMobil();
                return;
            }
            var hasilPencarian = _mobilRepository.SearchMobil(keyword);
            _view.TampilkanDataDiGrid(hasilPencarian);
        }

        public void TambahMobil(Mobil mobilBaru)
        {
            if (string.IsNullOrWhiteSpace(mobilBaru.Merek) || string.IsNullOrWhiteSpace(mobilBaru.Model))
            {
                MessageBox.Show("Merek dan Model tidak boleh kosong.", "Validasi Gagal", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            _mobilRepository.AddMobil(mobilBaru);
            LoadAllMobil();
        }

        public void HapusMobil(int id)
        {
            if (id == 0)
            {
                MessageBox.Show("ID mobil tidak valid untuk dihapus.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            _mobilRepository.DeleteMobil(id);
            LoadAllMobil();
        }

        public void UpdateMobil(Mobil mobilToUpdate)
        {
            if (mobilToUpdate.Id == 0)
            {
                MessageBox.Show("ID mobil tidak valid untuk diedit.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (string.IsNullOrWhiteSpace(mobilToUpdate.Merek) || string.IsNullOrWhiteSpace(mobilToUpdate.Model))
            {
                MessageBox.Show("Merek dan Model tidak boleh kosong.", "Validasi Gagal", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            _mobilRepository.UpdateMobil(mobilToUpdate);
            LoadAllMobil();
        }
    }
}
