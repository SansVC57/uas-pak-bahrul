﻿using Car_Management.Models;

namespace Car_Management.Controllers
{
    public class UserController
    {
        private readonly UserRepository _userRepository;

        public UserController()
        {
            _userRepository = new UserRepository();
        }

        public void Register(string nama, string email, string password)
        {
            User newUser = new User { NamaLengkap = nama, Email = email, Password = password };
            _userRepository.RegisterUser(newUser);
        }

        public User Login(string email, string password)
        {
            return _userRepository.LoginUser(email, password);
        }
    }
}
